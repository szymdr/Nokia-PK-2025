#include "IApplicationEnvironmentMock.hpp"

namespace ue
{

IApplicationEnvironmentMock::IApplicationEnvironmentMock() = default;
IApplicationEnvironmentMock::~IApplicationEnvironmentMock() = default;

}
