#include "IBtsPortMock.hpp"

namespace ue
{
IBtsEventsHandlerMock::IBtsEventsHandlerMock() = default;
IBtsEventsHandlerMock::~IBtsEventsHandlerMock() = default;

IBtsPortMock::IBtsPortMock() = default;
IBtsPortMock::~IBtsPortMock() = default;


}
