#include "IUserPortMock.hpp"

namespace ue
{
IUserEventsHandlerMock::IUserEventsHandlerMock() = default;
IUserEventsHandlerMock::~IUserEventsHandlerMock() = default;

IUserPortMock::IUserPortMock() = default;
IUserPortMock::~IUserPortMock() = default;


}
