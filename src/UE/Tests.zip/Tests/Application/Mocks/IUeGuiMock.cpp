#include "IUeGuiMock.hpp"

namespace ue
{

IUeGuiMock::IUeGuiMock() = default;
IUeGuiMock::~IUeGuiMock() = default;

IListViewModeMock::IListViewModeMock() = default;
IListViewModeMock::~IListViewModeMock() = default;

ITextModeMock::ITextModeMock() = default;
ITextModeMock::~ITextModeMock() = default;

ISmsComposeModeMock::ISmsComposeModeMock() = default;
ISmsComposeModeMock::~ISmsComposeModeMock() = default;

ICallModeMock::ICallModeMock() = default;
ICallModeMock::~ICallModeMock() = default;

IDialModeMock::IDialModeMock() = default;
IDialModeMock::~IDialModeMock() = default;

}
