#pragma once

#include "CommonEnvironment/ITransport.hpp"

namespace ue
{

using common::ITransport;
using common::BinaryMessage;

}
