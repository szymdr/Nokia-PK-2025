#include "IApplicationEnvironment.hpp"

// nothing to implement
