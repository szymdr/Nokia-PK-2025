#include "ITextMode.hpp"

// Empty file
