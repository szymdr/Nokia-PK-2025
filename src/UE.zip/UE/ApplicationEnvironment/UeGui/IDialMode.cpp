#include "IDialMode.hpp"

// Empty file
