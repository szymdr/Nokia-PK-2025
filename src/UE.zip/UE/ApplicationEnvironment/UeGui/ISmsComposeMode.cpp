#include "ISmsComposeMode.hpp"

// Empty file
