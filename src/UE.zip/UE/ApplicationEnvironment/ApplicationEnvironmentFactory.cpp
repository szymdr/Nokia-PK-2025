#include "ApplicationEnvironmentFactory.hpp"

namespace ue
{
// NOTE that createApplicationEnvironment() not implemented here
// It is assumend application will be linked with library,
// where IApplicationEnvironment will be specialized
// and thus createApplicationEnvironment() easily implemented.
}

