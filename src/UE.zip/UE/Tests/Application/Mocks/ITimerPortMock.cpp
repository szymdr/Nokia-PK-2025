#include "ITimerPortMock.hpp"

namespace ue
{

ITimerEventsHandlerMock::ITimerEventsHandlerMock() = default;
ITimerEventsHandlerMock::~ITimerEventsHandlerMock() = default;

ITimerPortMock::ITimerPortMock() = default;
ITimerPortMock::~ITimerPortMock() = default;

}
