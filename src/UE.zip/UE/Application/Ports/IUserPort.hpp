#pragma once
#include "Messages/PhoneNumber.hpp"

namespace ue
{

    class IUserEventsHandler
    {
    public:
        virtual ~IUserEventsHandler() = default;
//      handle sendsms
     };

    class IUserPort
    {
    public:
        virtual ~IUserPort() = default;

        virtual void showNotConnected() = 0;
        virtual void showConnecting() = 0;
        virtual void showConnected() = 0;

        virtual void showNewSms(bool present) = 0;

        // show sms compose
    };

}
